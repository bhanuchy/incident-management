import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
	   
	 def FileName = message.getHeaders().get("FileName");
	 if(FileName != null){
	     messageLog.addCustomHeaderProperty("FileName", FileName);
	    }
	}
return message;
}