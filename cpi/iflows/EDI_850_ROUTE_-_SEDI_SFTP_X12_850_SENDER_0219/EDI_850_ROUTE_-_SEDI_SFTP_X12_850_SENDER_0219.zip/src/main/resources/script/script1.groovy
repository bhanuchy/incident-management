import com.sap.it.api.ITApi.ValueMappingApi;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
	// Get properties
	map = message.getProperties();
	String mestyp = map.get("MESTYP");
	String doctyp = map.get("IDOCTYP");
	String sender = map.get("SNDPOR");
	String log_sys = map.get("SNDPRT");
	
	// Get ValueMapping API
	def api = ITApiFactory.getApi(ValueMappingApi.class, null);
	
	if (api == null) {
		throw new Exception("Could not retrieve ValueMappingAPI.");
	}
	
	// Get the value from value mapping
	String value = api.getMappedValue(sender, mestyp, log_sys, doctyp,"ProcessDirect");

	if (value == null ) {
		throw new Exception("No values found in the Value Mapping for Keys: " + sender + " : " + mestyp + " : " + log_sys + " : " + doctyp);
	}
	
	//Set Process Direct Address as Header
        message.setHeader("Address", value);
	return message;
}
