import com.sap.it.api.ITApiFactory;
import com.sap.it.api.mapping.ValueMappingApi;
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
 
    def Header = message.getHeaders();
    def iflow =Header.get('IFlowId');
    def packageid=Header.get('PackageID')
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)

    String check_decision = valueMapApi.getMappedValue(packageid, 'IFlowId',iflow, 'SIMTICKET', 'DECISION');

	if(check_decision == ""){

		check_decision = "YES"

    	}

    message.setHeader("check_decision",check_decision);
 
    return message;

}