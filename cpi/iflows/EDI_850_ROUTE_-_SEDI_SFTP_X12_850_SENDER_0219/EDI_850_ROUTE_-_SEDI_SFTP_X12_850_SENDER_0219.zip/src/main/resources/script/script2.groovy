import com.sap.gateway.ip.core.customdev.util.Message;

def Message Ack_Payload(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);
    
		if (messageLog != null) {
		    def body = message.getBody(java.lang.String) as String;
	      	messageLog.addAttachmentAsString("997_Payload", body, "text/xml");
		}

	return message;
}

def Message MDN_Payload(Message message) {
    
    def messageLog = messageLogFactory.getMessageLog(message);
    
		if (messageLog != null) {
		    def body = message.getBody(java.lang.String) as String;
	      	messageLog.addAttachmentAsString("MDN_PayLoad", body, "text/xml");
		}

	return message;
}
