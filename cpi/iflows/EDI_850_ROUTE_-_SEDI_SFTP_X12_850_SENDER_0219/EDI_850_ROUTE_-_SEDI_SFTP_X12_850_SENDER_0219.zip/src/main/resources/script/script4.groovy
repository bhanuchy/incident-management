import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def properties = message.getProperties()
    def Payload = properties.get("SourcePayload")
    def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
        messageLog.addAttachmentAsString("Payload", Payload, "text/plain")
    } 
    return message
}